﻿namespace BirthdayCelebrations
{
    public class Pet : Alive
    {
        public Pet(string name, string birthdate) : base(name, birthdate)
        {
        }
    }
}
