﻿namespace Farm
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Puppy puppy = new Puppy();
            puppy.Weep();
            puppy.Bark();
            puppy.Eat();
        }
    }
}
