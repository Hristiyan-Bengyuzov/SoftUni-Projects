﻿namespace PlanetWars.Models.MilitaryUnits
{
    public class StormTroopers : MilitaryUnit
    {
        public StormTroopers() : base(2.5)
        {
        }
    }
}
